package com.example.app.ui // ganti sesuai package project kamu

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

data class NavItem(
    val label: String,       // dipakai untuk accessibility saja
    val icon: ImageVector,
)

/**
 * Bottom bar melayang: tombol-tombol kotak bulat terpisah, hanya ikon.
 * Tombol yang aktif pakai warna primary aplikasi, sisanya polos.
 */
@Composable
fun FloatingNavBar(
    items: List<NavItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .navigationBarsPadding()
            .padding(bottom = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items.forEachIndexed { index, item ->
            val selected = index == selectedIndex

            val container by animateColorAsState(
                if (selected) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surface,
                label = "navContainer",
            )
            val tint by animateColorAsState(
                if (selected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant,
                label = "navTint",
            )

            Surface(
                onClick = { onSelect(index) },
                shape = RoundedCornerShape(20.dp),
                color = container,
                shadowElevation = 6.dp,
                modifier = Modifier.size(64.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = tint,
                        modifier = Modifier.size(28.dp),
                    )
                }
            }
        }
    }
}

/*
 * ===== CARA PAKAI =====
 *
 * 1. Hapus NavigationBar / bottomBar lama dari Scaffold.
 * 2. Tumpuk bar baru di atas konten:
 *
 * var selected by remember { mutableIntStateOf(0) }
 * val items = listOf(
 *     NavItem("Beranda", Icons.Default.Home),
 *     NavItem("Cari", Icons.Default.Search),
 *     NavItem("Pustaka", ikonPustakaKamu),   // pakai ikon not musik yang sekarang
 * )
 *
 * Box(Modifier.fillMaxSize()) {
 *     // konten layar (HomeScreen / SearchScreen / LibraryScreen)
 *     // beri contentPadding bawah sekitar 96.dp supaya item terakhir tidak tertutup
 *
 *     FloatingNavBar(
 *         items = items,
 *         selectedIndex = selected,
 *         onSelect = { selected = it },
 *         modifier = Modifier.align(Alignment.BottomCenter),
 *     )
 * }
 */
