package com.example.pingallery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val PinRed = Color(0xFFE60023)

// ---------- Data & ViewModel ----------

data class Pin(val id: Int, val url: String)

sealed interface UiState {
    data object Loading : UiState
    data object Empty : UiState
    data class Error(val message: String) : UiState
    data class Success(val pins: List<Pin>) : UiState
}

class GalleryViewModel : ViewModel() {
    var query by mutableStateOf("Spongebob")
    var state by mutableStateOf<UiState>(UiState.Loading)
        private set

    init {
        search()
    }

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        state = UiState.Loading
        viewModelScope.launch {
            state = try {
                val pins = withContext(Dispatchers.IO) { fetchPins(q) }
                if (pins.isEmpty()) UiState.Empty else UiState.Success(pins)
            } catch (e: Exception) {
                UiState.Error("Gagal mengambil data. Cek koneksi internet kamu.")
            }
        }
    }

    private fun fetchPins(q: String): List<Pin> {
        val url = URL("https://api.nexray.eu.cc/search/pinterest?q=${URLEncoder.encode(q, "UTF-8")}")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 15_000
        try {
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONObject(body).optJSONArray("result") ?: return emptyList()
            return (0 until arr.length()).mapNotNull { i ->
                val link = arr.optJSONObject(i)?.optString("images_url").orEmpty()
                if (link.isNotBlank()) Pin(i, link) else null
            }
        } finally {
            conn.disconnect()
        }
    }
}

// ---------- Activity ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(primary = PinRed, background = Color.White, surface = Color.White)
            ) {
                GalleryScreen()
            }
        }
    }
}

// ---------- UI ----------

@Composable
fun GalleryScreen(vm: GalleryViewModel = viewModel()) {
    var selected by remember { mutableStateOf<Pin?>(null) }
    val keyboard = LocalSoftwareKeyboardController.current
    val doSearch = {
        keyboard?.hide()
        vm.search()
    }

    Scaffold(
        containerColor = Color.White,
        topBar = {
            SearchField(
                value = vm.query,
                onValueChange = { vm.query = it },
                onSearch = doSearch,
            )
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
            when (val s = vm.state) {
                UiState.Loading -> CircularProgressIndicator(color = PinRed)
                UiState.Empty -> Text("Gambar tidak ditemukan.", color = Color.Gray)
                is UiState.Error -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp),
                ) {
                    Text(s.message, color = Color.Gray, textAlign = TextAlign.Center)
                    Button(
                        onClick = { vm.search() },
                        colors = ButtonDefaults.buttonColors(containerColor = PinRed),
                        modifier = Modifier.padding(top = 16.dp),
                    ) { Text("Coba lagi") }
                }
                is UiState.Success -> LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Adaptive(160.dp),
                    contentPadding = PaddingValues(8.dp),
                    verticalItemSpacing = 8.dp,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(s.pins, key = { it.id }) { pin ->
                        PinCard(pin) { selected = pin }
                    }
                }
            }
        }
    }

    selected?.let { FullImage(it) { selected = null } }
}

@Composable
private fun SearchField(value: String, onValueChange: (String) -> Unit, onSearch: () -> Unit) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        placeholder = { Text("Cari di Pinterest...") },
        trailingIcon = {
            IconButton(onClick = onSearch) {
                Icon(Icons.Default.Search, contentDescription = "Cari", tint = PinRed)
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        shape = RoundedCornerShape(28.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color(0xFFF1F1F1),
            unfocusedContainerColor = Color(0xFFF1F1F1),
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = PinRed,
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .padding(top = 28.dp),
    )
}

private val placeholderRatios = listOf(0.75f, 0.9f, 1f, 0.65f, 1.1f)

@Composable
private fun PinCard(pin: Pin, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val ratio = placeholderRatios[pin.id % placeholderRatios.size]
    SubcomposeAsyncImage(
        model = ImageRequest.Builder(ctx).data(pin.url).crossfade(true).build(),
        contentDescription = null,
        contentScale = ContentScale.FillWidth,
        loading = {
            Box(Modifier.fillMaxWidth().aspectRatio(ratio).background(Color(0xFFE9E9E9)))
        },
        error = {
            Box(
                Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFFF1F1F1)),
                contentAlignment = Alignment.Center,
            ) { Text("Gagal dimuat", color = Color.Gray) }
        },
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
    )
}

@Composable
private fun FullImage(pin: Pin, onDismiss: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            SubcomposeAsyncImage(
                model = pin.url,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                loading = {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color.White)
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            offset = if (scale == 1f) Offset.Zero else offset + pan
                        }
                    }
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y,
                    ),
            )
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 32.dp, end = 8.dp),
            ) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
            }
        }
    }
}
