package com.apkbuilder

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

const val TOKEN_URL = "https://github.com/settings/tokens/new?scopes=repo,workflow&description=APK%20Builder"

// ---------- Tema (Material You: warna ikut wallpaper di Android 12+) ----------

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        android.os.Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

// ---------- Kerangka: app bar besar + navigasi bawah ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Root(st: BuildState, act: Actions) {
    var tab by remember { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    val sb = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    BackHandler(enabled = tab == 1) { tab = 0 }
    LaunchedEffect(st.info) {
        val m = st.info
        if (m != null) {
            snack.showSnackbar(m)
            st.info = null
        }
    }

    Scaffold(
        modifier = Modifier.nestedScroll(sb.nestedScrollConnection),
        topBar = {
            LargeTopAppBar(
                title = { Text(if (tab == 0) "APK Builder" else "Panduan") },
                scrollBehavior = sb,
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Build, contentDescription = null) },
                    label = { Text("Build") },
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Info, contentDescription = null) },
                    label = { Text("Panduan") },
                )
            }
        },
        snackbarHost = { SnackbarHost(snack) },
    ) { pad ->
        if (tab == 0) BuildScreen(st, act, pad) { tab = 1 } else GuideScreen(act, pad)
    }
}

// ---------- Komponen kecil ----------

@Composable
fun Kartu(judul: String, isi: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(judul, style = MaterialTheme.typography.titleMedium)
            isi()
        }
    }
}

@Composable
fun FileRow(
    judul: String,
    nilai: String,
    kosong: Boolean,
    aktif: Boolean,
    onHapus: (() -> Unit)? = null,
    onPilih: () -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(1f)) {
            Text(judul, style = MaterialTheme.typography.labelLarge)
            Text(
                nilai,
                style = MaterialTheme.typography.bodyMedium,
                color = if (kosong) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (onHapus != null) TextButton(onClick = onHapus, enabled = aktif) { Text("Reset") }
        FilledTonalButton(onClick = onPilih, enabled = aktif) { Text("Pilih") }
    }
}

@Composable
fun Langkah(n: Int, teks: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(26.dp),
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "$n",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        }
        Text(teks, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
    }
}

@Composable
fun Masalah(judul: String, isi: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(judul, style = MaterialTheme.typography.labelLarge)
        Text(isi, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

fun namaFile(ctx: Context, u: Uri?): String? {
    if (u == null) return null
    return try {
        ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: u.lastPathSegment
    } catch (e: Exception) {
        "tidak bisa dibuka, pilih ulang"
    }
}

// ---------- Layar Build ----------

@Composable
fun BuildScreen(st: BuildState, act: Actions, pad: PaddingValues, keGuide: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val view = LocalView.current
    SideEffect { view.keepScreenOn = st.building }   // layar tetap nyala selama build

    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) act.pilih(u, true)
    }
    val pickYml = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) act.pilih(u, false)
    }
    val saveApk = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { u -> if (u != null) act.simpan(u) }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(st.building) {
        while (st.building) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    val zipNama = remember(st.zipUri) { namaFile(ctx, st.zipUri) }
    val ymlNama = remember(st.ymlUri) { namaFile(ctx, st.ymlUri) }

    Column(
        Modifier
            .padding(pad)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (st.token.isBlank() && !st.building) {
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                ),
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Pertama kali pakai?", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Kamu butuh token GitHub. Cara ambilnya ada di tab Panduan.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    TextButton(onClick = keGuide) { Text("Buka Panduan") }
                }
            }
        }

        Kartu("Akun GitHub") {
            OutlinedTextField(
                value = st.token,
                onValueChange = { st.token = it },
                label = { Text("Token GitHub") },
                singleLine = true,
                enabled = !st.building,
                visualTransformation = PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(
                        onClick = { clip.getText()?.text?.let { st.token = it.trim() } },
                        enabled = !st.building,
                    ) { Text("Tempel") }
                },
                supportingText = { Text("Jenis classic, scope: repo + workflow") },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = st.repo,
                onValueChange = { st.repo = it },
                label = { Text("Nama repo") },
                singleLine = true,
                enabled = !st.building,
                supportingText = { Text("Dibuat otomatis (private) kalau belum ada") },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Kartu("File") {
            FileRow("proyek.zip", zipNama ?: "Belum dipilih", zipNama == null, !st.building) {
                pickZip.launch(arrayOf("*/*"))
            }
            HorizontalDivider()
            FileRow(
                "build.yml (opsional)",
                ymlNama ?: "Bawaan",
                ymlNama == null,
                !st.building,
                onHapus = if (st.ymlUri != null) act.hapusYml else null,
            ) {
                pickYml.launch(arrayOf("*/*"))
            }
        }

        Button(
            onClick = act.mulai,
            enabled = !st.building,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
        ) {
            if (st.building) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = LocalContentColor.current,
                )
                Spacer(Modifier.width(10.dp))
                Text("Sedang build...")
            } else {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Build APK")
            }
        }

        // ----- Loading saat build -----
        if (st.building) {
            val detik = ((now - st.startedAt) / 1000).coerceAtLeast(0)
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Sedang membangun APK", style = MaterialTheme.typography.titleMedium)
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(st.status, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Waktu berjalan: " + "%02d:%02d".format(detik / 60, detik % 60),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        "Build berjalan di server GitHub, biasanya 3–8 menit. Jangan tutup aplikasi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        // ----- Gagal -----
        val err = st.error
        if (err != null && !st.building) {
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer,
                ),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Warning, contentDescription = null)
                        Text("Gagal", style = MaterialTheme.typography.titleMedium)
                    }
                    Text(err, style = MaterialTheme.typography.bodyMedium)
                    val url = st.logUrl
                    if (url != null) {
                        FilledTonalButton(onClick = { act.buka(url) }) { Text("Buka log di GitHub") }
                    }
                }
            }
        }

        // ----- Berhasil -----
        val f = st.apk
        if (f != null && !st.building) {
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                ),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Text("Build berhasil", style = MaterialTheme.typography.titleMedium)
                    }
                    Text(f.name + " · " + (f.length() / 1024) + " KB", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = act.pasang) { Text("Install") }
                        FilledTonalButton(onClick = { saveApk.launch(f.name) }) { Text("Simpan APK") }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
    }
}

// ---------- Layar Panduan ----------

@Composable
fun GuideScreen(act: Actions, pad: PaddingValues) {
    Column(
        Modifier
            .padding(pad)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Kartu("Cara pakai") {
            Langkah(1, "Ambil token GitHub (lihat kartu di bawah), lalu tempel di tab Build.")
            Langkah(
                2,
                "Pilih file proyek.zip, yaitu proyek Android (Gradle) yang mau dijadikan APK. " +
                    "File settings.gradle atau settings.gradle.kts harus ada di root zip, bukan di dalam subfolder.",
            )
            Langkah(3, "build.yml boleh dikosongkan. Kalau kosong, dipakai workflow bawaan.")
            Langkah(
                4,
                "Tekan Build APK. Aplikasi mengunggah proyek ke repo GitHub private milikmu, " +
                    "lalu server GitHub yang membangun APK-nya. Tunggu sekitar 3–8 menit dan jangan tutup aplikasi.",
            )
            Langkah(5, "Kalau berhasil, tekan Install atau Simpan APK.")
        }

        Kartu("Cara ambil token GitHub") {
            Langkah(1, "Tekan tombol di bawah. Login ke GitHub kalau diminta.")
            Langkah(2, "Kolom Note sudah terisi. Pilih Expiration, misalnya 30 atau 90 hari.")
            Langkah(3, "Pastikan scope repo dan workflow tercentang (biasanya sudah otomatis).")
            Langkah(4, "Scroll ke bawah, tekan Generate token.")
            Langkah(5, "Salin token yang muncul (diawali ghp_). Token hanya tampil sekali.")
            Langkah(6, "Kembali ke aplikasi ini, buka tab Build, lalu tekan Tempel di kolom token.")
            Button(onClick = { act.buka(TOKEN_URL) }, modifier = Modifier.fillMaxWidth()) {
                Text("Buka halaman buat token")
            }
            Text(
                "Anggap token seperti password dan jangan dibagikan. Token disimpan di HP ini saja. " +
                    "Pakai token jenis classic.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Kartu("Masalah umum") {
            Masalah("Token belum punya scope 'workflow'", "Buat token baru lewat tombol di atas, pastikan repo dan workflow tercentang.")
            HorizontalDivider()
            Masalah("Token salah atau kedaluwarsa", "Buat token baru, lalu tempel ulang di tab Build.")
            HorizontalDivider()
            Masalah("Build gagal", "Tekan Buka log di GitHub, lalu lihat langkah yang berwarna merah untuk tahu penyebabnya.")
            HorizontalDivider()
            Masalah("Install tidak jalan", "Izinkan 'install dari sumber ini' untuk aplikasi APK Builder, lalu tekan Install lagi.")
        }

        Spacer(Modifier.height(8.dp))
    }
}
