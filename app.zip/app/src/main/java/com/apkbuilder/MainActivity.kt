package com.apkbuilder

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import java.io.File
import kotlin.concurrent.thread

/** Semua data yang tampil di layar. */
class BuildState {
    var token by mutableStateOf("")
    var repo by mutableStateOf("apk-builder")
    var zipUri by mutableStateOf<Uri?>(null)
    var ymlUri by mutableStateOf<Uri?>(null)
    var building by mutableStateOf(false)
    var status by mutableStateOf("")
    var startedAt by mutableStateOf(0L)
    var apk by mutableStateOf<File?>(null)
    var error by mutableStateOf<String?>(null)
    var logUrl by mutableStateOf<String?>(null)
    var info by mutableStateOf<String?>(null)
}

/** Aksi yang dipanggil dari UI. */
class Actions(
    val pilih: (Uri, Boolean) -> Unit,
    val hapusYml: () -> Unit,
    val mulai: () -> Unit,
    val pasang: () -> Unit,
    val simpan: (Uri) -> Unit,
    val buka: (String) -> Unit,
)

class MainActivity : ComponentActivity() {

    private val st = BuildState()
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        st.token = prefs.getString("token", "") ?: ""
        st.repo = prefs.getString("repo", "apk-builder") ?: "apk-builder"
        st.zipUri = prefs.getString("zip", null)?.let { Uri.parse(it) }
        st.ymlUri = prefs.getString("yml", null)?.let { Uri.parse(it) }

        val act = Actions(
            pilih = { u, zip -> pilih(u, zip) },
            hapusYml = { hapusYml() },
            mulai = { mulai() },
            pasang = { pasang() },
            simpan = { u -> simpanKe(u) },
            buka = { url -> buka(url) },
        )
        setContent { AppTheme { Root(st, act) } }
    }

    private fun pilih(u: Uri, zip: Boolean) {
        try {
            contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
        }
        if (zip) {
            st.zipUri = u
            prefs.edit().putString("zip", u.toString()).apply()
        } else {
            st.ymlUri = u
            prefs.edit().putString("yml", u.toString()).apply()
        }
    }

    private fun hapusYml() {
        st.ymlUri = null
        prefs.edit().remove("yml").apply()
    }

    private fun baca(u: Uri): ByteArray = try {
        contentResolver.openInputStream(u)?.use { it.readBytes() } ?: throw Gagal("File tidak bisa dibaca.")
    } catch (e: SecurityException) {
        throw Gagal("Izin ke file hilang. Pilih ulang file-nya.")
    }

    private fun masalah(pesan: String) {
        st.error = pesan
        st.logUrl = null
        st.apk = null
    }

    private fun mulai() {
        if (st.building) return
        val tk = st.token.trim()
        val rp = st.repo.trim().ifEmpty { "apk-builder" }.replace(Regex("[^A-Za-z0-9_.-]"), "-")
        val z = st.zipUri
        if (tk.isEmpty()) { masalah("Isi token GitHub dulu. Belum punya? Lihat tab Panduan."); return }
        if (z == null) { masalah("Pilih file proyek.zip dulu."); return }

        prefs.edit().putString("token", tk).putString("repo", rp).apply()
        st.repo = rp
        st.error = null
        st.logUrl = null
        st.apk = null
        st.status = "Mulai..."
        st.startedAt = System.currentTimeMillis()
        st.building = true
        val y = st.ymlUri

        thread {
            try {
                val zipBytes = baca(z)
                val yml = if (y != null) baca(y) else DEFAULT_YML.toByteArray()
                val (nm, bytes) = Gh(tk).build(rp, zipBytes, yml) { t -> runOnUiThread { st.status = t } }
                val dir = File(cacheDir, "apk")
                dir.deleteRecursively()
                dir.mkdirs()
                val f = File(dir, nm)
                f.writeBytes(bytes)
                runOnUiThread {
                    st.apk = f
                    st.building = false
                }
            } catch (e: Gagal) {
                runOnUiThread {
                    st.error = e.message ?: "Gagal"
                    st.logUrl = e.url
                    st.building = false
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    st.error = "Error: " + (e.message ?: e.javaClass.simpleName)
                    st.building = false
                }
            }
        }
    }

    private fun pasang() {
        val f = st.apk ?: return
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            st.info = "Izinkan install dari aplikasi ini, lalu tekan Install lagi."
            return
        }
        val u = FileProvider.getUriForFile(this, "$packageName.fp", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(u, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun simpanKe(u: Uri) {
        val f = st.apk ?: return
        try {
            contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            st.info = "APK tersimpan."
        } catch (e: Exception) {
            st.info = "Gagal simpan: " + (e.message ?: "")
        }
    }

    private fun buka(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            st.info = "Tidak ada browser untuk membuka link."
        }
    }
}
