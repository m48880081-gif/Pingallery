package com.apkbuilder

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private var zipUri: Uri? = null
    private var ymlUri: Uri? = null
    private var apk: File? = null
    private var logUrl: String? = null

    private lateinit var token: EditText
    private lateinit var repo: EditText
    private lateinit var zipLbl: TextView
    private lateinit var ymlLbl: TextView
    private lateinit var status: TextView
    private lateinit var btnBuild: Button
    private lateinit var btnInstall: Button
    private lateinit var btnSave: Button
    private lateinit var btnLog: Button

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun btn(label: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { f() }
        return b
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(24))

        fun add(v: View) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            root.addView(v, lp)
        }

        val judul = TextView(this)
        judul.text = "APK Builder"
        judul.textSize = 26f
        add(judul)

        token = EditText(this)
        token.hint = "Token GitHub (classic: repo + workflow)"
        token.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        token.setText(prefs.getString("token", ""))
        add(token)

        repo = EditText(this)
        repo.hint = "Nama repo"
        repo.setText(prefs.getString("repo", "apk-builder"))
        add(repo)

        zipLbl = TextView(this)
        ymlLbl = TextView(this)
        add(btn("Pilih proyek.zip") { pick(1) })
        add(zipLbl)
        add(btn("Pilih build.yml (opsional)") { pick(2) })
        add(ymlLbl)

        btnBuild = btn("Build APK") { mulai() }
        add(btnBuild)

        status = TextView(this)
        status.textSize = 15f
        status.setTextIsSelectable(true)
        add(status)

        btnInstall = btn("Install") { pasang() }
        btnSave = btn("Simpan APK") { simpan() }
        btnLog = btn("Buka log di GitHub") { buka() }
        add(btnInstall)
        add(btnSave)
        add(btnLog)
        sembunyi()

        zipUri = prefs.getString("zip", null)?.let { Uri.parse(it) }
        ymlUri = prefs.getString("yml", null)?.let { Uri.parse(it) }
        tampil()

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    private fun sembunyi() {
        btnInstall.visibility = View.GONE
        btnSave.visibility = View.GONE
        btnLog.visibility = View.GONE
    }

    private fun nama(u: Uri?): String {
        if (u == null) return "belum dipilih"
        return try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            } ?: u.lastPathSegment ?: "file"
        } catch (e: Exception) {
            "tidak bisa dibuka, pilih ulang"
        }
    }

    private fun tampil() {
        zipLbl.text = "proyek: " + nama(zipUri)
        ymlLbl.text = "build.yml: " + (if (ymlUri == null) "bawaan" else nama(ymlUri))
    }

    private fun pick(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, code)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        if (res != RESULT_OK || d == null) return
        val u = d.data ?: return
        when (req) {
            1, 2 -> {
                try {
                    contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                if (req == 1) {
                    zipUri = u
                    prefs.edit().putString("zip", u.toString()).apply()
                } else {
                    ymlUri = u
                    prefs.edit().putString("yml", u.toString()).apply()
                }
                tampil()
            }
            3 -> simpanKe(u)
        }
    }

    private fun baca(u: Uri): ByteArray =
        contentResolver.openInputStream(u)?.use { it.readBytes() } ?: throw Gagal("File tidak bisa dibaca.")

    private fun say(t: String) = runOnUiThread { status.text = t }

    private fun mulai() {
        val tk = token.text.toString().trim()
        val rp = repo.text.toString().trim().ifEmpty { "apk-builder" }.replace(Regex("[^A-Za-z0-9_.-]"), "-")
        val z = zipUri
        if (tk.isEmpty()) { status.text = "Isi token GitHub dulu."; return }
        if (z == null) { status.text = "Pilih proyek.zip dulu."; return }
        prefs.edit().putString("token", tk).putString("repo", rp).apply()
        btnBuild.isEnabled = false
        sembunyi()
        status.text = "Mulai..."
        val y = ymlUri
        thread {
            try {
                val zipBytes = baca(z)
                val yml = if (y != null) baca(y) else DEFAULT_YML.toByteArray()
                val (nm, bytes) = Gh(tk).build(rp, zipBytes, yml) { say(it) }
                val dir = File(cacheDir, "apk")
                dir.deleteRecursively()
                dir.mkdirs()
                val f = File(dir, nm)
                f.writeBytes(bytes)
                runOnUiThread {
                    apk = f
                    status.text = "Selesai: $nm (${f.length() / 1024} KB)"
                    btnInstall.visibility = View.VISIBLE
                    btnSave.visibility = View.VISIBLE
                    btnBuild.isEnabled = true
                }
            } catch (e: Gagal) {
                runOnUiThread {
                    status.text = e.message ?: "Gagal"
                    logUrl = e.url
                    if (e.url != null) btnLog.visibility = View.VISIBLE
                    btnBuild.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Error: " + (e.message ?: e.javaClass.simpleName)
                    btnBuild.isEnabled = true
                }
            }
        }
    }

    private fun pasang() {
        val f = apk ?: return
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            status.text = "Izinkan install dari aplikasi ini, lalu tekan Install lagi."
            return
        }
        val u = FileProvider.getUriForFile(this, "$packageName.fp", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(u, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    @Suppress("DEPRECATION")
    private fun simpan() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/vnd.android.package-archive"
        i.putExtra(Intent.EXTRA_TITLE, apk?.name ?: "app.apk")
        startActivityForResult(i, 3)
    }

    private fun simpanKe(u: Uri) {
        val f = apk ?: return
        try {
            contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            status.text = "APK tersimpan."
        } catch (e: Exception) {
            status.text = "Gagal simpan: " + (e.message ?: "")
        }
    }

    private fun buka() {
        val u = logUrl ?: return
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    }
}
