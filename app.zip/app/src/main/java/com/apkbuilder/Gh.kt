package com.apkbuilder

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipInputStream

const val API = "https://api.github.com"

/** Workflow bawaan, dipakai kalau build.yml tidak dipilih. */
const val DEFAULT_YML = """name: Build APK
on:
  push:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Ekstrak proyek
        run: unzip -oq proyek.zip
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: "8.9"
      - run: gradle assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: APK
          path: app/build/outputs/apk/debug/*.apk
"""

class Gagal(msg: String, val url: String? = null) : Exception(msg)

class Gh(private val token: String) {

    class Res(val code: Int, val text: String, val loc: String?) {
        val ok: Boolean get() = code in 200..299
        fun json() = JSONObject(text)
    }

    private fun call(method: String, url: String, body: JSONObject? = null): Res {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.instanceFollowRedirects = false
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code >= 400) c.errorStream else c.inputStream
        val text = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        val loc = c.getHeaderField("Location")
        c.disconnect()
        return Res(code, text, loc)
    }

    private fun pesan(r: Res): String =
        try { JSONObject(r.text).optString("message", r.text.take(200)) } catch (e: Exception) { r.text.take(200) }

    private fun gitSha(d: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-1")
        md.update("blob ${d.size}\u0000".toByteArray())
        md.update(d)
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Upload file ke repo. Return false kalau isinya sama persis (dilewati). */
    private fun taruh(rp: String, branch: String, path: String, data: ByteArray, say: (String) -> Unit): Boolean {
        val url = "$API/repos/$rp/contents/$path"
        for (attempt in 1..3) {
            val cur = call("GET", "$url?ref=$branch")
            var sha: String? = null
            if (cur.ok) {
                sha = cur.json().optString("sha")
                if (sha == gitSha(data)) {
                    say("$path tidak berubah")
                    return false
                }
            }
            say("Upload $path...")
            val body = JSONObject()
                .put("message", "build: $path")
                .put("content", Base64.encodeToString(data, Base64.NO_WRAP))
                .put("branch", branch)
            if (sha != null) body.put("sha", sha)
            val r = call("PUT", url, body)
            if (r.ok) return true
            if ((r.code == 409 || r.code == 422) && attempt < 3) {
                Thread.sleep(2000)
                continue
            }
            throw Gagal("Upload $path gagal (${r.code}): ${pesan(r)}")
        }
        throw Gagal("Upload $path gagal berulang kali")
    }

    private fun lastRunId(rp: String): Long {
        val r = call("GET", "$API/repos/$rp/actions/runs?per_page=1")
        if (!r.ok) return 0L
        val arr = r.json().getJSONArray("workflow_runs")
        return if (arr.length() > 0) arr.getJSONObject(0).getLong("id") else 0L
    }

    private fun steps(rp: String, runId: Long): List<JSONObject> {
        val r = call("GET", "$API/repos/$rp/actions/runs/$runId/jobs")
        if (!r.ok) return emptyList()
        val jobs = r.json().getJSONArray("jobs")
        val out = ArrayList<JSONObject>()
        for (i in 0 until jobs.length()) {
            val st = jobs.getJSONObject(i).optJSONArray("steps") ?: continue
            for (k in 0 until st.length()) out.add(st.getJSONObject(k))
        }
        return out
    }

    private fun apkDariZip(zip: ByteArray, url: String): Pair<String, ByteArray> {
        ZipInputStream(zip.inputStream()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (!e.isDirectory && e.name.endsWith(".apk")) {
                    return e.name.substringAfterLast('/') to z.readBytes()
                }
            }
        }
        throw Gagal("Tidak ada file .apk di dalam artifact.", url)
    }

    /**
     * Alur lengkap: repo -> upload -> picu workflow -> tunggu -> unduh APK.
     * Return (nama file apk, isi apk).
     */
    fun build(repoName: String, proyek: ByteArray, yml: ByteArray, say: (String) -> Unit): Pair<String, ByteArray> {
        say("Cek akun GitHub...")
        val me = call("GET", "$API/user")
        if (!me.ok) throw Gagal("Token ditolak (${me.code}): ${pesan(me)}")
        val owner = me.json().getString("login")
        val rp = "$owner/$repoName"

        say("Cek repo $rp...")
        var repo = call("GET", "$API/repos/$rp")
        if (repo.code == 404) {
            say("Membuat repo private...")
            repo = call(
                "POST", "$API/user/repos",
                JSONObject().put("name", repoName).put("private", true).put("auto_init", true)
            )
            if (!repo.ok) throw Gagal("Gagal membuat repo (${repo.code}): ${pesan(repo)}")
            Thread.sleep(3000)
        } else if (!repo.ok) {
            throw Gagal("Gagal membuka repo (${repo.code}): ${pesan(repo)}")
        }
        val branch = repo.json().getString("default_branch")

        val before = lastRunId(rp)
        val a = taruh(rp, branch, "proyek.zip", proyek, say)
        val b = taruh(rp, branch, ".github/workflows/build.yml", yml, say)

        if (!a && !b) {
            say("Tidak ada perubahan, jalankan ulang workflow...")
            val d = call(
                "POST", "$API/repos/$rp/actions/workflows/build.yml/dispatches",
                JSONObject().put("ref", branch)
            )
            if (!d.ok) throw Gagal("Gagal memicu workflow (${d.code}): ${pesan(d)}")
        }

        val ref = call("GET", "$API/repos/$rp/git/ref/heads/$branch")
        if (!ref.ok) throw Gagal("Gagal baca branch (${ref.code}): ${pesan(ref)}")
        val sha = ref.json().getJSONObject("object").getString("sha")

        say("Menunggu workflow mulai...")
        var runId = 0L
        var tries = 0
        while (runId == 0L) {
            if (tries++ > 40) throw Gagal("Workflow tidak muncul. Cek tab Actions di repo.", "https://github.com/$rp/actions")
            val rs = call("GET", "$API/repos/$rp/actions/runs?per_page=10&head_sha=$sha")
            if (rs.ok) {
                val arr = rs.json().getJSONArray("workflow_runs")
                for (i in 0 until arr.length()) {
                    val r = arr.getJSONObject(i)
                    if (r.getLong("id") > before) {
                        runId = r.getLong("id")
                        break
                    }
                }
            }
            if (runId == 0L) Thread.sleep(3000)
        }
        val runUrl = "https://github.com/$rp/actions/runs/$runId"

        var conclusion = ""
        var polls = 0
        while (conclusion.isEmpty()) {
            if (polls++ > 360) throw Gagal("Build lebih dari 30 menit. Cek di GitHub.", runUrl)
            val r = call("GET", "$API/repos/$rp/actions/runs/$runId")
            if (r.ok) {
                val j = r.json()
                if (j.getString("status") == "completed") {
                    conclusion = j.optString("conclusion", "unknown")
                    break
                }
                val aktif = steps(rp, runId).firstOrNull { it.optString("status") == "in_progress" }?.optString("name") ?: ""
                say(if (aktif.isEmpty()) "Build antre / mulai..." else "Build: $aktif")
            }
            Thread.sleep(5000)
        }

        if (conclusion != "success") {
            val bad = steps(rp, runId).firstOrNull { it.optString("conclusion") == "failure" }?.optString("name")
            val di = if (bad != null) " di langkah: $bad" else " ($conclusion)"
            throw Gagal("Build gagal$di. Buka log untuk detailnya.", runUrl)
        }

        var artId = 0L
        for (k in 1..5) {
            val ar = call("GET", "$API/repos/$rp/actions/runs/$runId/artifacts")
            if (ar.ok) {
                val l = ar.json().getJSONArray("artifacts")
                if (l.length() > 0) {
                    artId = l.getJSONObject(0).getLong("id")
                    break
                }
            }
            Thread.sleep(3000)
        }
        if (artId == 0L) throw Gagal("Build sukses tapi artifact APK tidak ada.", runUrl)

        say("Mengunduh APK...")
        val dl = call("GET", "$API/repos/$rp/actions/artifacts/$artId/zip")
        val loc = dl.loc ?: throw Gagal("Link unduhan tidak ada (${dl.code}).", runUrl)
        val c = URL(loc).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 120000
        val zip = c.inputStream.use { it.readBytes() }
        return apkDariZip(zip, runUrl)
    }
}
